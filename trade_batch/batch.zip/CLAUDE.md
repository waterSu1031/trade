# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Spring Boot batch application for collecting and processing trading data from Interactive Brokers (IBKR) API. The system collects futures market data, processes it into time series and range bars, and stores it in PostgreSQL databases.

## Build and Development Commands

### Maven Commands
- `mvn clean install` - Clean build and install dependencies
- `mvn spring-boot:run` - Run the application
- `mvn test` - Run tests
- `mvn compile` - Compile the project

### Running Batch Jobs
The application supports multiple batch jobs that can be triggered via REST endpoints:
- `POST /batch/job/{jobName}` - Execute specific batch job
- Available jobs: `setInitStructureJob`, `addFutureMonthJob`, `collectTypeDataJob`, `taskletJob`

## Architecture

### Core Components

**IBKR Integration (`com.trade.batch.ibkr`)**
- `ClientIBKR` - Main client for Interactive Brokers API connection and data retrieval
- `ListenIBKR` - Base class for handling IBKR callbacks
- `BarVO` - Value object for bar data

**Batch Processing (`com.trade.batch.job`)**
- `CollectDataJob` - Main batch job configuration with multiple job definitions:
  - Contract initialization job
  - Future month collection job  
  - Time series data collection job
  - Range data conversion job

**Data Services (`com.trade.batch.service`)**
- `CollectDataService` - Core service for data collection and processing
- `CommonService` - Shared utility services

**Database Configuration (`com.trade.batch.config`)**
- `JdbcDataSourceRouter` - Dynamic database routing for multiple PostgreSQL instances
- Supports two databases: TRADE and DATA_US

### Database Architecture
- **TRADE DB**: Contains contract definitions, exchange data, and metadata
- **DATA_US DB**: Stores time series market data (minute bars, range bars)
- Uses PostgreSQL with manual JDBC configuration (JPA is commented out)

### Key Processing Flow
1. **Contract Initialization**: Load symbols from CSV, fetch contract details from IBKR
2. **Future Month Collection**: Collect available contract months for futures
3. **Time Data Collection**: Fetch historical minute bar data from IBKR
4. **Range Conversion**: Convert time-based bars to range-based bars

## Configuration

### Application Properties
- Database connections configured in `application.yaml`
- IBKR API connection: `localhost:4002` with client ID 30
- Logging configured via `logback-spring.xml` with file rotation

### Environment Variables
- `DB_PASSWORD` - PostgreSQL password (defaults to hardcoded value)

### Dependencies
- Spring Boot 3.5.3 with Java 24
- Spring Batch for job processing
- PostgreSQL, SQLite, and DuckDB JDBC drivers
- IBKR TwsApi.jar (local dependency in `/lib`)
- Redis for caching/messaging
- Netty for networking

## Development Notes

### IBKR API Integration
- The system connects to Interactive Brokers TWS or IB Gateway
- Uses asynchronous pattern with CompletableFuture for API calls
- Handles connection management with automatic retry logic

### Batch Job Patterns
- Uses Spring Batch chunk-based processing
- Configurable chunk sizes (typically 6-10 items)
- Built-in retry and error handling
- Sleep delays between API calls to respect rate limits

### Testing
- Basic test structure in place with `BatchApplicationTests`
- No specific test commands documented - use standard `mvn test`

### Logging
- Comprehensive logging setup with daily rotation
- Separate error log files
- Debug level logging for application packages
- Async appenders for performance