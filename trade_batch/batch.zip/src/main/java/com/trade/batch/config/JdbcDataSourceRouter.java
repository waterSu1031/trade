package com.trade.batch.config;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;

@Component
public class JdbcDataSourceRouter {

    public JdbcTemplate getJdbcTemplate(String dbName) {
        String url = "jdbc:postgresql://localhost:5432/" + dbName;
        DataSource ds = DataSourceBuilder.create()
                .driverClassName("org.postgresql.Driver")
                .url(url)
                .username("postgres")
                .password("${DB_PASSWORD:Lsld1501!}")
                .build();
        return new JdbcTemplate(ds);
    }
}
